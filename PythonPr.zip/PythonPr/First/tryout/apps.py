from django.apps import AppConfig


class TryoutConfig(AppConfig):
    name = 'tryout'
