
from django.shortcuts import render
from .models import numbers #imports class NUMBERS from models.py
from .forms import NumbersForm, NumbersEntry, WholeNumbersForm  #import form NUMBERSFORM from forms.py
  

