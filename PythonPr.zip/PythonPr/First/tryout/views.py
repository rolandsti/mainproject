from django.http import HttpResponse, Http404
from django.shortcuts import render, get_object_or_404
from .models import numbers, content, cities #imports class NUMBERS from models.py
from .forms import *  #import form NUMBERSFORM from forms.py
from .functions import *
from .test_functions import *
from django.http import JsonResponse
from .forms import numbers_form, testing_numbers
from django.core import serializers
import json
import os
import os.path
import requests
import re
	

def numbers_main_view(request): ### history button and search

	context = main_page_function(request);
	return render(request, "numbers/main.html", context)



def numbers_entry_view(request, entry_id): ### opens individual entries

	try:
		context = entry_page_function(request, entry_id)
		return render(request, "numbers/main_entry.html", context)

	except:
		raise Http404("Impossible action")


	

def numbers_delete_view (request, entry_id): ### deletes entries when called upon

	try:
		delete_entry_function(request, entry_id)
		data = {'info' : 'Entry has been deleted!'}
		return JsonResponse(data)

	except:
		raise Http404("Impossible action")



def numbers_edit_view (request, entry_id): ### edits entries in individual entry page

	try:
		data = edit_entry_function(request, entry_id)
		print(entry_id)
		return JsonResponse(data)

	except:

		raise Http404("Impossible action")

def numbers_create_view(request):  ### creates new entrie in main page

	try:
		data = create_entry_function(request)		
		return JsonResponse(data)

	except:

		raise Http404("Impossible action")
	


def settings_view(request): ### opens up settings page

	return render(request, 'settings/settings.html')


def search_keyword_view(request):
	
	try:
		form = KeySearchForm()
		result = search_keyword_function(request)

		data = {
		"found_result_count": 	result["found_result_count"],
		"final_data": 			result["final_data"],
		"form":					form,
		}
		

	except:
		form = KeySearchForm()
		data = {
			"form": form,
			"somealert": "Something went horribly wrong... try different keyword:(",
		}
	return render(request, 'searching.html', data)






def  api_search_keyword_view(request):
	try:
		result = search_keyword_function(request)
		

	except:
		found_result_count = 0
		result = {
			"found_result_count": 	found_result_count,
		}
	return JsonResponse(result)





def apimerge_view(request, *args, **kwargs):

	if request.method == "GET":

		city_to_find = request.GET.get('location')

		if city_to_find and len(city_to_find) <= 100:

			result = list_of_cities_function(request)

			if result['result_count'] < 7000:
				data = {
					"result_count"	: result["result_count"],
					"final_data"	: result["final_data"],
					"input"			: city_to_find,
					}
			else:
				data = {
					"result_count"	: result["result_count"],
					"final_data"	: result["final_data"],
					"somealert"		: "There are 7000+ resuts... please be more specific",
					"input"			: city_to_find,
					}

			return render(request, 'apimerge/apimerge.html', data)

		else:
			if city_to_find and len(city_to_find) > 300:
				data = {"somealert" : "Invalid request"}
				return render(request, 'apimerge/apimerge.html', data)
			else:
				return render(request, 'apimerge/apimerge.html')

			








def apimerge_entry_view(request, keystring):
	try:
		if request.method == 'GET':
			city_id = keystring
			
			if len(city_id) < 10:
				query_params = "?id=" + city_id
				link = "http://apitaskapi.us-e2.cloudhub.io/api/getsomedata" + query_params

				data = requests.get(link).json()			
				call_code = data['country']['call_code']
				call_text = str(call_code) + ' is a call code of ' + data['country']['country_name']



				allnumbers = numbers.objects.all()
				dublicate = False
				for number in allnumbers:			
					if str(call_code) in str(number.number) and data['country']['country_name'] in number.fact and 'call code' in number.fact:
						dublicate = True

				if dublicate == False: #if there is record about this country it will no be recorded again
					new_entry = {
					'number' : call_code,
					'fact'	: call_text,
					}			
					numbers.objects.create(**new_entry)


				return render(request, "apimerge/apimerge_entry.html", data)

			else:
				data = {
					"somealert": "Invalid request",
				}
				return render(request, "apimerge/apimerge.html", data)


	except:

		data = {
					"somealert": "Invalid request",
				}

	
		return render(request, "apimerge/apimerge.html", data)



def api_search_weather_view(request):
	found_result_count = 0
	count = 5
	if request.method == 'GET' and request.GET.get('city') != None:

		city = request.GET.get('city')

		if request.GET.get('count') != None:
			count = request.GET.get('count')
			try:
				count = int(count)
				if count > 5:
					count = 5
				elif count < 0:
					count = 0
			except:
				count = 5

		final_data = []
		all_cities = cities.objects.all()

		for one_city in all_cities:
			if city.lower() in one_city.name.lower():
			
				found_result_count += 1
				query_params = "?id=" + one_city.city_id
				link = "http://apitaskapi.us-e2.cloudhub.io/api/getsomedata" + query_params
				print(link)
				found_result = requests.get(link).json()
				final_data.append(found_result)

				if found_result_count >= count:
					break




		data = {
			"found_result_count": found_result_count,
			"found_results": final_data,
		}
		
	else:
		data = {
			"found_result_count": found_result_count,
		}

	return JsonResponse(data, safe=False)



def list_of_cities_view(request):

	try:
		data = list_of_cities_function(request)
	except:
		found_result_count = 0
		data = {"result_count": found_result_count,}
	return JsonResponse(data, safe=False)





def barba_nasa_view(request):
	try:
		if request.method == "GET" and request.GET.get('id') != None:
			date = request.GET.get('id')
			nasa = "https://catsandayliens.herokuapp.com/space/?date=" + date;
			nasa_data = requests.get(nasa).json()

			date = result = re.sub('[^0-9]','', nasa_data['date'])
			if "youtube" in nasa_data['url']:
				text = 'In ' +  nasa_data["date"] +' NASA picture of the day was "' +  nasa_data["title"] + '". ' + nasa_data["url"]
			else:
				text = 'In ' +  nasa_data["date"] +' NASA picture of the day was "' +  nasa_data["title"] + '". ' + nasa_data["hdurl"]

			allnumbers = numbers.objects.all()
			dublicate = False
			for number in allnumbers:			
				if str(date) in str(number.number) and nasa_data["date"] in number.fact and 'NASA' in number.fact:
					dublicate = True

			if dublicate == False: #if there is record about this country it will no be recorded again
				new_entry = {
				'number' : date,
				'fact'	: text,
				}			
				numbers.objects.create(**new_entry)

		
			return render(request, 'interns/nasa.html', nasa_data)
		else:

			return render(request, 'interns/nasa.html')
	except:

		return render(request, 'interns/nasa.html')


def json_db_response(request, entry_id): 

		obj = numbers.objects.get(id=entry_id)
		text = obj.fact	
		text = text.split(" ")
		for word in text:
			if word.startswith("https://") == True or word.startswith("http://"):
				link = word
		data = {
			'link': word,
		}
		return JsonResponse(data)

def apidocs_view(request):

	return render(request, 'apimerge/apidocs.html')

##### JSON file conversion to SQLlite ###
	# base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
	# file_path = os.path.join(base_path, "tryout/templates/apimerge/smol_list.json")
	# print(file_path)
	# json_data = open(file_path, encoding="utf8")
	# data_load = json.load(json_data)
	# 
	# for city in data_load:
	# 	entry = {
	# 		"name": city['name'],
	# 		"country": city['country'],
	# 		"city_id": city['id']
	# 	}
	# cities.objects.create(**entry)

	# data = json.dumps(data_load)
	# json_data.close
	# return JsonResponse(data, safe=False)
##########################################

##########################################

#### DOWN FROM HERE IS NOTHING WORTHY ####

##########################################



def stuff_create_view(request):
	my_form = testing_numbers()
	if request.method == "POST":

		my_form = testing_numbers(request.POST) #request post is for validation
		if my_form.is_valid(): #data is comfirmed by fields
			print(my_form.cleaned_data)
			content.objects.create(**my_form.cleaned_data)
			
		else:
			print(my_form.errors)
	# context = {			this is optional (less efficient) way, how you could add context
	#	"title": obj.title,
	#	"description": obj.description
	#}

	context = {
		"form" 	: my_form,
		"sss"	: "title"
		
	}

	###############
	###############

	# 
	# 	if request.method == "POST":
	# 		record = request.POST.get('title')
	# 		print(record)
	# 	context = {
	# 		'stuff': record,
	# 	}

	#############
	#############

		# form = numbers_form(request.POST or None)
		# if form.is_valid():
		# 	#form.save()
		# 	form = numbers_form() #clears out the form
		# context = {		
		# 	'form': form
		# }

	return render(request, "numbers/main_create.html", context)




def home_view(request, *args, **kwargs):
	context = {
		"location" : "Home",
		"some_number" : 10
	}
	return render(request, "home.html", context)


def about_view(request,*args, **kwargs):
	context = {
		"location" : "About",
		"some_number" : 10,
		"some_list": [111, 222, 333, "Hello"]
	}
	return render(request, 'about.html', context)


def string_view(*args, **kwargs):
	return HttpResponse("<h1>Hello</h1>") #html string

##########################